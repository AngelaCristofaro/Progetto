package progetto.progetto;

public class Utente {
	private String mail; 
	private String password;
	//private int ruolo;
	
	Utente (String mail,String password) {
		this.mail = mail;
		this.password = password;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getMail() {
		return mail;
	}
	
	public String getPassword() {
		return password;
	}
	
	@Override
	public boolean equals(Object o) {	
		Utente u = (Utente) o;
		return this.mail == u.mail;
	}
}
