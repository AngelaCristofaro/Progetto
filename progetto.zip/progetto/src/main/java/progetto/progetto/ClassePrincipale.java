package progetto.progetto;

import java.time.LocalDateTime;

import progetto.risorse.Laptop;
import progetto.risorse.Sala;

public class ClassePrincipale {
 public static void main(String[] args) {
	 Utente utente = new Utente ("asfdfghjasfghj@o", "kjasfhfbkj");
	 Utente utente2 = new Utente ("asafdgsdfhg@o", "kjasfhfbkj");
	 Utente u = new Utente ("aç","kjasfhfbkj");
	 GestioneUtente gu = new GestioneUtente();
	 gu.aggiungiUtente(utente.getMail(),utente.getPassword());
	// gu.aggiungiUtente(utente2);
	// gu.aggiungiUtente(u);
	 Risorsa r = new Laptop (89);
	 Risorsa r2 = new Laptop (89);
	 Risorsa r1 = new Sala(20);
	 GestioneRisorse gr = new GestioneRisorse();
	 gr.aggiungiRisorsa(r);
	 gr.aggiungiRisorsa(r1);
	 Prenotazioni pre=new Prenotazioni(utente,r,LocalDateTime.of(2010, 8, 9, 12, 34), LocalDateTime.of(2030, 8, 9, 12, 34));
	 //Prenotazioni pre1=new Prenotazioni(utente,r1.getId(),LocalDateTime.now(), LocalDateTime.of(2030, 8, 9, 12, 34) );
	 GestionePrenotazione gp = new GestionePrenotazione();
	 gp.insertPre(utente,r,LocalDateTime.of(2010, 8, 9, 12, 34), LocalDateTime.of(2017, 8, 9, 12, 34));
	 //gp.insertPre(pre1);
	 //System.out.println(GestioneRisorse.StampaRisorse());
	 //System.out.println(GestionePrenotazione.StampaPrenotazioni());
	// GestionePrenotazione.ElencoMiePrenotazioni(u);
	 //System.out.println(Database.treeMapPrenotazione);
	 // System.out.println(utente.getMail());
	// System.out.println(Database.treeMapUtente);
	// gp.consegna(pre, LocalDateTime.of(2013,4,1,2,1,1));
	 //GestionePrenotazione.ElencoMiePrenotazioniOra(utente);
	 //gp.risorsaDisponibile(r);
 gp.risorsaDisponibileData( r,LocalDateTime.of(2909, 8, 9, 12, 34),LocalDateTime.of(2979, 8, 9, 12, 34));
	
}
}
