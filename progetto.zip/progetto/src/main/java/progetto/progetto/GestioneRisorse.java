package progetto.progetto;

import java.util.ArrayList;
import java.util.List;

public class GestioneRisorse {

	static RisorsaDao<Risorsa> rd = new RisorsaDao<Risorsa>();
	
	public void aggiungiRisorsa(Risorsa risorsa) {
		if (controllaRisorsa(risorsa) == false) {
		rd.insert(risorsa);}
		else {
			System.out.println("La Risorsa esiste già");
		}		
	}
	
	public void eliminaRisorsa(Risorsa risorsa) {
		if(controllaRisorsa(risorsa))
		{rd.delete(risorsa); }
	}	
	
	public void updateRisorsa(Risorsa risorsa) {
		if(controllaRisorsa(risorsa))
		{rd.update(risorsa);}
		else {
			System.out.println("La Risorsa non esiste");
		}
	}
	
	public static <T> List<Risorsa> StampaRisorse(String tipo, int caratteristica) {
		List<Risorsa> ris = new ArrayList<>();
		for (Risorsa r : RisorsaDao.getListaRisorse().values()) {
			if (r.getClass().getSimpleName().equals(tipo) && r.getCaratteristica() == caratteristica)
			{ris.add(r);}
		} 
			return ris;
		}
	
	public static <T> List<Risorsa> StampaRisorseTipo(String tipo) {
		List<Risorsa> risoTipo = new ArrayList<>();
		for (Risorsa r : RisorsaDao.getListaRisorse().values()) {
			if (r.getClass().getSimpleName().equals(tipo))
			{risoTipo.add(r);}
		} 
			return risoTipo;
		}
	
	public boolean controllaRisorsa(Risorsa risorsa) {
		for (int id : RisorsaDao.getListaRisorse().keySet()) {
			if(risorsa.getId()==id) 
			{return true;} 
		}
		return false;    
	}

}

