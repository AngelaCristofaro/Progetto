package progetto.progetto;

public class GestioneUtente {
	UtenteDao<Utente> ud = new UtenteDao<Utente>();


	public boolean controlloDati(String mail, String password) {
		if(controlloMail(mail) && controllopassword(password))
		{
			return true;
		} 
		else {
			System.out.println("Inserisci mail corretta o "); 
			System.out.println("Inserisci password di almeno 8 caratteri");
			return false;
		}	   
	}
	
		public boolean controlloMail(String mail) {
			if(mail.indexOf('@')>-1) {
				return true;
			}
			else {
				return false;
			}
		}
		
		public boolean controllopassword(String password) {
			if(password.length()>8) {
				return true;
			}
			else {
				return false;
			}
		} 
		
	   public void aggiungiUtente(String mail, String password) {
		   if (controlloDati(mail,password)) {
			   Utente utente = new Utente(mail, password);
			   ud.insert(utente); 
			}
		}
	   
	   public void eliminaUtente(Utente utente) {
		   if (controllaUtente(utente.getMail())) {
			   ud.delete(utente); 
		   }
	   }	
	   public void updateUtente(Utente utente) {
		   if (controllaUtente(utente.getMail())) {
			   ud.update(utente); 
		   }
		   else {
			System.out.println("L'utente non esiste");
		   }
	   }
	   
	   public boolean controllaUtente(String mail) {
		   for (String mail1 : UtenteDao.getListaUtenti().keySet()) {
			   if(mail.equals(mail1)) 
			   		{return true;} 
		}
		   			return false;    
	}


}
