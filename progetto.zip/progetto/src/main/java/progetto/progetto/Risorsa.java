package progetto.progetto;

import java.util.concurrent.atomic.AtomicInteger;

public abstract class Risorsa { 
		private int caratteristica;
		private int id;
		private static AtomicInteger i = new AtomicInteger();
		
		public Risorsa(int caratteristica) {
			this.id = i.incrementAndGet(); 
			this.caratteristica= caratteristica;
				}
		
		public int getId() {
			return id; 
		}
		
		public void setId(int id) { 
			this.id = id;
		}
		
		public int getCaratteristica() {
			return caratteristica;
		}
		
		public void setCaratteristica(int caratteristica) {
			this.caratteristica = caratteristica;
		}
		
		@Override
		public boolean equals(Object o) {
			Risorsa r = (Risorsa) o;
			return this.id == r.id;
		}		
}

