package progetto.progetto;

import java.util.TreeMap;

public class RisorsaDao <T extends Risorsa> implements IntefacciaDao <T>{
	static TreeMap<Integer, Risorsa> treeMapRisorsa = new TreeMap<>();
	@Override
	public void insert(T r) {
		treeMapRisorsa.put(r.getId(), r);	
	}

	@Override
	public void delete(T r) {
		treeMapRisorsa.remove(r.getId(), r);		
	}

	@Override
	public void update(T r) {
		treeMapRisorsa.put(r.getId(), r);	
	}
	
	public static TreeMap<Integer,Risorsa> getListaRisorse() {
		return treeMapRisorsa;
	}
}

