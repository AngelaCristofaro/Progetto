package progetto.progetto;

import java.util.TreeMap;
public class UtenteDao <T extends Utente> implements IntefacciaDao<T> {
	
	static TreeMap<String, Utente> treeMapUtente = new TreeMap<>();
	
	@Override
	public void insert(T u) {
	   treeMapUtente.put(u.getMail(), u);
	}

	@Override
	public void delete(T u) {
		treeMapUtente.remove(u.getMail(), u);		
	}

	@Override
	public void update(T u) {
		treeMapUtente.put(u.getMail(), u);	
	}
	
	public static void setTreeMapUtente(TreeMap<String, Utente> treeMapUtente) {
		UtenteDao.treeMapUtente = treeMapUtente;
	}

	public static TreeMap<String,Utente> getListaUtenti() {
		return treeMapUtente;
	}
	
	
}


