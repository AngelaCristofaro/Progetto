package progetto.progetto;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class Prenotazioni {
	
	private int idPrenotazione;
	public LocalDateTime  dataInizio;
	public LocalDateTime  dataFine;
	private long durata = -1;
	private Utente utente;
	private Risorsa r;
	private LocalDateTime dataConsegna;
	
	public  LocalDateTime getDataConsegna() {
		return dataConsegna;
	}

	public void setDataConsegna(LocalDateTime dataConsegna) {
		this.dataConsegna = dataConsegna;
	}

	private static AtomicInteger i=new AtomicInteger();
	public Prenotazioni(Utente utente, Risorsa r , LocalDateTime  dataInizio,LocalDateTime  dataFine) {
		this.idPrenotazione = i.incrementAndGet(); 
		this.durata = ChronoUnit.HOURS.between(dataInizio, dataFine);
		this.utente = utente;
		this.r=r;
		this.dataInizio = dataInizio;
		this.dataFine= dataFine;
	}
	
	public int getR() {
		return r.getId();
	}
	
	public Risorsa getRis() {
		return r;
	}

	public void setR(Risorsa r) {
		this.r = r;
	}

	public void setDurata(long durata) {
		this.durata = durata; 
	}
	
	public LocalDateTime getDataInizio() {
		return dataInizio;
	}

	public void setDataInizio(LocalDateTime dataInizio) {
		this.dataInizio = dataInizio;
	}

	public LocalDateTime getDataFine() {
		return dataFine;
	}

	public void setDataFine(LocalDateTime dataFine) {
		this.dataFine = dataFine;
	}


	public void setUtente(Utente utente) {
		this.utente = utente;
	}

	
	public Utente getUtente() {
		return this.utente;
	}

	public long getDurata() {
		return  durata;
	}
			
	public int getIdPrenotazione() {
		return idPrenotazione;
	}
	
	@Override
	public boolean equals(Object o) {
		Prenotazioni p = (Prenotazioni) o;
		return this.idPrenotazione == p.idPrenotazione;
	}


}