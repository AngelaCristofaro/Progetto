package progetto.risorse;

import progetto.progetto.Risorsa;

public class Sala extends Risorsa {
		public Sala(int posti) {
			// TODO Auto-generated constructor stub
			super(posti);
		}


}
