package progetto.risorse;

import progetto.progetto.Risorsa;

public class Laptop extends Risorsa {
	public Laptop(int ram) {
		// TODO Auto-generated constructor stub
		super(ram);
	}

}
